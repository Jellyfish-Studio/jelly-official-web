// Jelly Web Helper - Popup Script

document.addEventListener("DOMContentLoaded", async () => {
  // 设置版本号
  const manifest = chrome.runtime.getManifest();
  document.getElementById("version").textContent = `v${manifest.version}`;

  // 获取连接状态
  updateConnectionStatus();

  // 加载设置
  loadSettings();

  // 设置模态框事件监听
  setupModalListeners();

  // 定期更新状态
  setInterval(updateConnectionStatus, 2000);
});

// 更新连接状态
async function updateConnectionStatus() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: "get_connection_status",
    });

    const statusDot = document.getElementById("statusDot");
    const statusText = document.getElementById("statusText");

    if (response.isAuthenticated) {
      statusDot.className = "status-dot connected";
      statusText.textContent = "已连接";
    } else if (response.state === "connecting") {
      statusDot.className = "status-dot connecting";
      statusText.textContent = "连接中...";
    } else if (response.state === "connected") {
      statusDot.className = "status-dot connecting";
      statusText.textContent = "认证中...";
    } else {
      statusDot.className = "status-dot disconnected";
      statusText.textContent = "未连接";
    }
  } catch (error) {
    console.error("Failed to get connection status:", error);
    const statusDot = document.getElementById("statusDot");
    const statusText = document.getElementById("statusText");
    statusDot.className = "status-dot disconnected";
    statusText.textContent = "错误";
  }
}

// 设置模态框事件监听
function setupModalListeners() {
  const modal = document.getElementById("providersModal");
  const showButton = document.getElementById("showProvidersList");
  const closeButton = document.getElementById("closeModal");

  // 点击链接显示模态框
  showButton.addEventListener("click", (e) => {
    e.preventDefault();
    showProvidersModal();
  });

  // 点击关闭按钮关闭模态框
  closeButton.addEventListener("click", () => {
    modal.classList.remove("show");
  });

  // 点击模态框背景关闭
  modal.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.classList.remove("show");
    }
  });
}

// 显示支持的网站列表
function showProvidersModal() {
  const modal = document.getElementById("providersModal");
  const providersList = document.getElementById("providersList");

  // 获取所有注册的 providers，过滤掉 GenericProvider
  const providers = (window.JELLY_PROVIDERS || []).filter(
    (provider) => provider.name !== "未知"
  );

  // 清空列表
  providersList.innerHTML = "";

  // 添加所有 provider 名称
  providers.forEach((provider) => {
    const li = document.createElement("li");
    li.className = "provider-item";
    li.textContent = provider.name;
    providersList.appendChild(li);
  });

  // 显示模态框
  modal.classList.add("show");
}

// 加载设置
async function loadSettings() {
  try {
    // 从 storage 加载设置
    const settings = await chrome.storage.local.get({
      autoSubmit: false,
      preferExistingTab: true,
      startNewChat: true,
    });

    // 设置复选框状态
    document.getElementById("autoSubmit").checked = settings.autoSubmit;
    document.getElementById("preferExistingTab").checked =
      settings.preferExistingTab;
    document.getElementById("startNewChat").checked = settings.startNewChat;

    // 更新startNewChat的显示状态
    updateStartNewChatVisibility(settings.preferExistingTab);

    // 添加事件监听器
    document
      .getElementById("autoSubmit")
      .addEventListener("change", async (e) => {
        await chrome.storage.local.set({ autoSubmit: e.target.checked });
      });

    document
      .getElementById("preferExistingTab")
      .addEventListener("change", async (e) => {
        await chrome.storage.local.set({
          preferExistingTab: e.target.checked,
        });
        // 更新startNewChat的显示状态
        updateStartNewChatVisibility(e.target.checked);
      });

    document
      .getElementById("startNewChat")
      .addEventListener("change", async (e) => {
        await chrome.storage.local.set({
          startNewChat: e.target.checked,
        });
      });
  } catch (error) {
    console.error("Failed to load settings:", error);
  }
}

// 更新"开启新对话"配置项的显示状态
function updateStartNewChatVisibility(preferExistingTab) {
  const container = document.getElementById("startNewChatContainer");
  if (container) {
    container.style.display = preferExistingTab ? "block" : "none";
  }
}
