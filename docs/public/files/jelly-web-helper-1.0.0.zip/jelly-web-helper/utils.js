// 共享工具函数

// 等待元素出现
function waitForElement(selectors, timeout = 10000) {
  if (!Array.isArray(selectors)) {
    selectors = [selectors];
  }

  return new Promise((resolve, reject) => {
    const startTime = Date.now();

    const check = () => {
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
          resolve(element);
          return;
        }
      }

      if (Date.now() - startTime > timeout) {
        reject(
          new Error(
            `Element not found after ${timeout}ms. Tried selectors: ${selectors.join(
              ", "
            )}`
          )
        );
        return;
      }

      setTimeout(check, 100);
    };

    check();
  });
}

// 设置原生值（绕过 React 等框架的控制）
function setNativeValue(element, value) {
  const valueSetter =
    Object.getOwnPropertyDescriptor(element, "value")?.set ||
    Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), "value")
      ?.set;

  if (valueSetter) {
    valueSetter.call(element, value);
  } else {
    element.value = value;
  }
}
