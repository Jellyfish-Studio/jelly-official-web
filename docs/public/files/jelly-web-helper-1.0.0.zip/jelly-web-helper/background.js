// Jelly Web Helper - Background Service Worker
// Manages WebSocket connection to Jelly app

// Detect browser Bundle ID for auto-activation
function getBrowserBundleId() {
  const userAgent = navigator.userAgent.toLowerCase();

  if (userAgent.includes("edg/")) return "com.microsoft.edgemac";
  if (userAgent.includes("arc")) return "company.thebrowser.Browser";
  if (userAgent.includes("brave")) return "com.brave.Browser";
  if (userAgent.includes("vivaldi")) return "com.vivaldi.Vivaldi";
  if (userAgent.includes("opr/") || userAgent.includes("opera"))
    return "com.operasoftware.Opera";
  if (userAgent.includes("chrome")) return "com.google.Chrome";

  return "com.google.Chrome"; // Default fallback
}

const WS_URL = "ws://localhost:9527";
const RECONNECT_DELAYS = [1000, 2000, 5000, 10000, 30000]; // 指数退避

let ws = null;
let isAuthenticated = false;
let reconnectAttempt = 0;
let reconnectTimer = null;

// 连接状态
const ConnectionState = {
  DISCONNECTED: "disconnected",
  CONNECTING: "connecting",
  CONNECTED: "connected",
  AUTHENTICATED: "authenticated",
};

let currentState = ConnectionState.DISCONNECTED;

// Content script 就绪状态管理
const readyTabs = new Set(); // 记录已就绪的 tab ID
const pendingMessages = new Map(); // 记录等待发送的消息 Map<tabId, {message, timer, url}>
const PENDING_MESSAGE_TIMEOUT = 5000; // 5秒超时

// 浏览器启动时连接
chrome.runtime.onStartup.addListener(() => {
  console.log("[Jelly] Browser started, connecting to WebSocket");
  connectWebSocket();
});

// 扩展安装或更新时连接
chrome.runtime.onInstalled.addListener(() => {
  console.log("[Jelly] Extension installed/updated, connecting to WebSocket");
  connectWebSocket();
});

// 启动时连接
console.log("[Jelly] Background service worker started");
connectWebSocket();

// 监听来自 content script 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[Jelly] Received message from content:", message);

  if (message.type === "content_ready") {
    // Content script 已就绪
    const tabId = sender.tab?.id;
    if (tabId) {
      console.log("[Jelly] 🤝 Content script ready for tab:", tabId);
      readyTabs.add(tabId);

      // 检查是否有等待发送的消息
      const pending = pendingMessages.get(tabId);
      if (pending) {
        console.log("[Jelly] 📤 Sending pending message to tab:", tabId);
        clearTimeout(pending.timer); // 清除超时定时器
        chrome.tabs.sendMessage(tabId, pending.message);
        pendingMessages.delete(tabId);
      }
    }
    sendResponse({ received: true });
  } else if (message.type === "fill_result") {
    // 转发操作结果到 Jelly app
    if (ws && ws.readyState === WebSocket.OPEN && isAuthenticated) {
      sendMessage(message);
    }
    sendResponse({ received: true });
  } else if (message.type === "get_connection_status") {
    // 返回连接状态
    sendResponse({
      state: currentState,
      isAuthenticated: isAuthenticated,
    });
  }

  return true; // 保持消息通道开放
});

// 监听标签页关闭，清理状态
chrome.tabs.onRemoved.addListener((tabId) => {
  console.log("[Jelly] Tab removed:", tabId);

  // 清理超时定时器
  const pending = pendingMessages.get(tabId);
  if (pending) {
    clearTimeout(pending.timer);
  }

  readyTabs.delete(tabId);
  pendingMessages.delete(tabId);
});

// 连接 WebSocket
function connectWebSocket() {
  if (
    ws &&
    (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)
  ) {
    console.log("[Jelly] WebSocket already connecting or connected");
    return;
  }

  currentState = ConnectionState.CONNECTING;
  console.log("[Jelly] Connecting to WebSocket:", WS_URL);

  try {
    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
      console.log("[Jelly] WebSocket connected");
      currentState = ConnectionState.CONNECTED;
      reconnectAttempt = 0; // 重置重连计数
      authenticate();
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log("[Jelly] Received message:", message);
        handleMessage(message);
      } catch (error) {
        console.error("[Jelly] Failed to parse message:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("[Jelly] WebSocket error:", error);
    };

    ws.onclose = (event) => {
      console.log("[Jelly] WebSocket closed:", event.code, event.reason);
      currentState = ConnectionState.DISCONNECTED;
      isAuthenticated = false;
      scheduleReconnect();
    };
  } catch (error) {
    console.error("[Jelly] Failed to create WebSocket:", error);
    scheduleReconnect();
  }
}

// 安排重连
function scheduleReconnect() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
  }

  const delay =
    RECONNECT_DELAYS[Math.min(reconnectAttempt, RECONNECT_DELAYS.length - 1)];
  console.log(
    `[Jelly] Reconnecting in ${delay}ms (attempt ${reconnectAttempt + 1})`
  );

  reconnectTimer = setTimeout(() => {
    reconnectAttempt++;
    connectWebSocket();
  }, delay);
}

// 认证
async function authenticate() {
  try {
    const token = await readToken();

    const authMessage = {
      type: "auth",
      data: {
        token: token,
        extensionVersion: chrome.runtime.getManifest().version,
        browserBundleId: getBrowserBundleId(),
      },
      timestamp: Date.now(),
    };

    sendMessage(authMessage);
  } catch (error) {
    console.error("[Jelly] Authentication failed:", error);
  }
}

// 读取 token（使用固定 salt）
async function readToken() {
  // 使用固定的 salt，与 Jelly app 保持一致
  // 这对于本地 localhost 连接来说足够安全
  return "jelly-web-helper-2024";
}

// 处理消息
function handleMessage(message) {
  switch (message.type) {
    case "auth_response":
      handleAuthResponse(message.data);
      break;

    case "fill_prompt":
      handleFillPrompt(message.data);
      break;

    case "pong":
      // 心跳响应
      console.log("[Jelly] Received pong");
      break;

    default:
      console.warn("[Jelly] Unknown message type:", message.type);
  }
}

// 处理认证响应
function handleAuthResponse(data) {
  if (data.success) {
    console.log("[Jelly] ✅ Authentication successful");
    isAuthenticated = true;
    currentState = ConnectionState.AUTHENTICATED;
  } else {
    console.error("[Jelly] ❌ Authentication failed:", data.message);

    // 检查是否是被新客户端断开
    if (data.message && data.message.includes("New client connected")) {
      console.warn(
        "[Jelly] ⚠️ Disconnected: Another browser connected to Jelly"
      );
      console.warn(
        "[Jelly] 💡 Only one browser can be connected at a time (last-in-wins)"
      );
    }

    isAuthenticated = false;
    currentState = ConnectionState.CONNECTED;
  }
}

// 处理填充提示词请求
async function handleFillPrompt(data) {
  console.log("[Jelly] Filling prompt:", data);

  try {
    const targetUrl = data.url; // Jelly app 传递的目标 URL

    if (!targetUrl) {
      throw new Error("No target URL provided");
    }

    // 从 storage 读取 preferExistingTab 设置
    const { preferExistingTab = true } = await chrome.storage.local.get(
      "preferExistingTab"
    );

    // 判断是否应该复用 tab（forceReuseExistingTab 优先级最高）
    const shouldReuseTab = data.forceReuseExistingTab || preferExistingTab;

    // 查找匹配的标签页（根据设置决定是否复用）
    let targetTab = null;

    if (shouldReuseTab) {
      targetTab = await findTabByUrl(targetUrl);
    }

    if (targetTab) {
      // 找到匹配的标签页，切换到该标签页
      console.log("[Jelly] Found existing tab:", targetTab.id);
      await chrome.tabs.update(targetTab.id, { active: true });
      await chrome.windows.update(targetTab.windowId, { focused: true });
    } else if (!data.forceReuseExistingTab) {
      // 没有找到或设置为不复用，创建新标签页
      console.log("[Jelly] Creating new tab for:", targetUrl);
      targetTab = await chrome.tabs.create({ url: targetUrl, active: true });
    } else {
      // forceReuseExistingTab=true 但没有找到匹配的 tab
      // 轮询等待外部创建的 tab，超时 5 秒
      console.log(
        "[Jelly] forceReuseExistingTab=true but no tab found, polling..."
      );

      const pollStartTime = Date.now();
      const pollTimeout = 5000;
      const pollInterval = 200; // 每 200ms 轮询一次

      while (Date.now() - pollStartTime < pollTimeout) {
        targetTab = await findTabByUrl(targetUrl);
        if (targetTab) {
          console.log("[Jelly] Found tab during polling:", targetTab.id);
          break;
        }
        // 等待下一次轮询
        await new Promise((resolve) => setTimeout(resolve, pollInterval));
      }

      if (!targetTab) {
        // 超时后仍未找到 tab
        throw new Error(
          `Timeout waiting for tab creation (${pollTimeout}ms). forceReuseExistingTab=true but no matching tab found for URL: ${targetUrl}`
        );
      }
    }

    // 准备要发送的消息
    const messageToSend = {
      type: "fill_prompt",
      data: {
        prompt: data.prompt,
      },
    };

    console.log("[Jelly] 📤 Preparing to send message to tab:", targetTab.id);
    console.log("[Jelly] 📤 Tab URL:", targetTab.url);
    console.log("[Jelly] 📤 Tab ready:", readyTabs.has(targetTab.id));

    // 检查 content script 是否已就绪
    if (readyTabs.has(targetTab.id)) {
      // 已就绪，立即发送
      console.log("[Jelly] 📤 Content script ready, sending immediately");
      chrome.tabs.sendMessage(targetTab.id, messageToSend);
    } else {
      // 未就绪，等待握手消息
      console.log("[Jelly] ⏳ Waiting for content script ready signal");

      // 设置超时定时器
      const timeoutTimer = setTimeout(() => {
        console.error("[Jelly] ⏰ Timeout waiting for content script ready");

        // 清理 pending 消息
        pendingMessages.delete(targetTab.id);

        // 向主应用发送超时错误
        sendMessage({
          type: "fill_result",
          data: {
            success: false,
            message: "Content script initialization timeout (5s)",
            url: targetUrl,
          },
          timestamp: Date.now(),
        });
      }, PENDING_MESSAGE_TIMEOUT);

      // 保存消息和定时器
      pendingMessages.set(targetTab.id, {
        message: messageToSend,
        timer: timeoutTimer,
        url: targetUrl,
      });
    }
  } catch (error) {
    console.error("[Jelly] Error handling fill_prompt:", error);

    // 发送失败结果
    sendMessage({
      type: "fill_result",
      data: {
        success: false,
        message: error.message,
        url: data.url || "unknown",
      },
      timestamp: Date.now(),
    });
  }
}

// 查找匹配 URL 的标签页
async function findTabByUrl(targetUrl) {
  try {
    const url = new URL(targetUrl);
    const tabs = await chrome.tabs.query({});

    console.log("[Jelly] 🔍 Finding tab for URL:", targetUrl);
    console.log(
      "[Jelly] 📋 Target - origin:",
      url.origin,
      "pathname:",
      url.pathname
    );
    console.log("[Jelly] 📑 Total tabs to check:", tabs.length);

    // 查找 domain + path 匹配的标签页
    for (const tab of tabs) {
      if (!tab.url) {
        console.log(`[Jelly] ⏭️  Tab ${tab.id}: no URL, skipping`);
        continue;
      }

      try {
        const tabUrl = new URL(tab.url);

        console.log(
          `[Jelly] 🔎 Tab ${tab.id}: origin="${tabUrl.origin}" pathname="${tabUrl.pathname}"`
        );

        // 匹配 origin + pathname
        if (
          tabUrl.origin === url.origin &&
          tabUrl.pathname.startsWith(url.pathname)
        ) {
          console.log(`[Jelly] ✅ MATCH FOUND! Tab ${tab.id}`);
          return tab;
        } else {
          const originMatch = tabUrl.origin === url.origin;
          const pathMatch = tabUrl.pathname === url.pathname;
          console.log(
            `[Jelly] ❌ No match - origin: ${originMatch}, pathname: ${pathMatch}`
          );
        }
      } catch (e) {
        console.log(`[Jelly] ⚠️  Tab ${tab.id}: invalid URL, skipping`);
        continue;
      }
    }

    console.log("[Jelly] 🚫 No matching tab found");
    return null;
  } catch (error) {
    console.error("[Jelly] Error finding tab:", error);
    return null;
  }
}

// 发送消息
function sendMessage(message) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(message));
  } else {
    console.error("[Jelly] Cannot send message: WebSocket not connected");
  }
}

// 心跳
setInterval(() => {
  if (ws && ws.readyState === WebSocket.OPEN && isAuthenticated) {
    sendMessage({
      type: "ping",
      data: {}, // 添加空的 data 字段
      timestamp: Date.now(),
    });
  }
}, 30000); // 每 30 秒发送一次心跳
