// DeepSeek Provider
const DeepSeekProvider = {
  name: "DeepSeek",
  urlPattern: /https?:\/\/chat\.deepseek\.com/i,

  adapter: {
    async waitForInputBox(timeout = 10000) {
      const selectors = ["textarea", 'div[contenteditable="true"]'];

      return waitForElement(selectors, timeout);
    },

    fillText(inputBox, text) {
      if (inputBox.tagName === "TEXTAREA") {
        setNativeValue(inputBox, text);
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        inputBox.textContent = text;
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      }
    },

    async submit(inputBox) {
      const submitButton = document.querySelector("div._7436101"); // 这个可能不太稳定，不过deepseek的提交按钮没啥明显特征，先用着

      if (submitButton && !submitButton.disabled) {
        submitButton.click();
        return true;
      }

      return false; // 未找到提交按钮
    },

    getNewChatButton() {
      // DeepSeek的新对话按钮选择器
      return document.querySelector("div._5a8ac7a");
    },
  },
};

// Auto-register to global provider list
if (!window.JELLY_PROVIDERS) window.JELLY_PROVIDERS = [];
window.JELLY_PROVIDERS.push(DeepSeekProvider);
