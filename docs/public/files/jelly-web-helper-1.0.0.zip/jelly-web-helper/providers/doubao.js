// Doubao Provider (豆包)
const DoubaoProvider = {
  name: "豆包",
  urlPattern: /https?:\/\/(www\.)?doubao\.com/i,

  adapter: {
    async waitForInputBox(timeout = 10000) {
      const selectors = ["textarea", 'div[contenteditable="true"]'];

      return waitForElement(selectors, timeout);
    },

    async fillText(inputBox, text) {
      // 豆包填充文本需要延迟一会，有时候输入会莫名其妙被清除（可能是网页本身逻辑）
      await new Promise((resolve) => setTimeout(resolve, 500));

      if (inputBox.tagName === "TEXTAREA") {
        setNativeValue(inputBox, text);
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        inputBox.textContent = text;
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      }
    },

    async submit(inputBox) {
      const submitButton = document.querySelector(
        'button[id="flow-end-msg-send"]'
      );

      if (submitButton && !submitButton.disabled) {
        submitButton.click();
        return true;
      }

      return false; // 未找到提交按钮
    },

    getNewChatButton() {
      // 豆包的新对话按钮选择器
      return document.querySelector(
        'div[data-testid="create_conversation_button"]'
      );
    },
  },
};

// Auto-register to global provider list
if (!window.JELLY_PROVIDERS) window.JELLY_PROVIDERS = [];
window.JELLY_PROVIDERS.push(DoubaoProvider);
