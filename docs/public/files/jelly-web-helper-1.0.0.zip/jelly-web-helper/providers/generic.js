// Generic Provider (Fallback)
const GenericProvider = {
  name: "未知",
  // No URL pattern - used as fallback

  adapter: {
    async waitForInputBox(timeout = 10000) {
      // 尝试常见的输入框选择器
      const selectors = [
        "textarea",
        'div[contenteditable="true"]',
        'input[type="text"]',
        "#prompt",
        ".prompt",
        "[placeholder*='message' i]",
        "[placeholder*='prompt' i]",
        "[placeholder*='ask' i]",
        "[placeholder*='chat' i]",
      ];

      return waitForElement(selectors, timeout);
    },

    fillText(inputBox, text) {
      if (inputBox.tagName === "TEXTAREA" || inputBox.tagName === "INPUT") {
        setNativeValue(inputBox, text);
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
        inputBox.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        // contenteditable div
        inputBox.textContent = text;
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
        inputBox.dispatchEvent(new Event("change", { bubbles: true }));
      }
    },

    async submit(inputBox) {
      // 尝试多种常见的提交按钮选择器
      const submitButton =
        document.querySelector('button[type="submit"]') ||
        document.querySelector('button[aria-label*="Send"]') ||
        document.querySelector('button[aria-label*="发送"]') ||
        Array.from(document.querySelectorAll("button")).find(
          (btn) =>
            btn.textContent.includes("Send") ||
            btn.textContent.includes("发送") ||
            btn.textContent.includes("Submit") ||
            btn.textContent.includes("提交")
        );

      if (submitButton && !submitButton.disabled) {
        submitButton.click();
        return true;
      }

      // 如果没找到按钮，尝试按 Enter
      inputBox.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          bubbles: true,
        })
      );
      return true; // 假设 Enter 键会成功
    },

    getNewChatButton() {
      // 通用的新对话按钮选择器
      return (
        Array.from(document.querySelectorAll("button")).find(
          (btn) =>
            btn.textContent.includes("New chat") ||
            btn.textContent.includes("新对话") ||
            btn.textContent.includes("新建对话") ||
            btn.textContent.includes("New Chat") ||
            btn.textContent.includes("Start new")
        ) ||
        Array.from(document.querySelectorAll("a")).find(
          (a) =>
            a.textContent.includes("New chat") ||
            a.textContent.includes("新对话") ||
            a.textContent.includes("新建对话") ||
            a.href === "/" ||
            a.href.endsWith("/")
        )
      );
    },
  },
};

// Auto-register to global provider list (as fallback)
if (!window.JELLY_PROVIDERS) window.JELLY_PROVIDERS = [];
window.JELLY_PROVIDERS.push(GenericProvider);
