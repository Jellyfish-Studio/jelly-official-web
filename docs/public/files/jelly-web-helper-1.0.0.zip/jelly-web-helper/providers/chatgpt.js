// ChatGPT Provider
const ChatGPTProvider = {
  name: "ChatGPT",
  urlPattern: /https?:\/\/(chat\.openai\.com|chatgpt\.com)/i,

  adapter: {
    async waitForInputBox(timeout = 10000) {
      const selectors = [
        "#prompt-textarea",
        'textarea[placeholder*="Message"]',
        'div[contenteditable="true"]',
      ];

      return waitForElement(selectors, timeout);
    },

    fillText(inputBox, text) {
      if (inputBox.tagName === "TEXTAREA") {
        setNativeValue(inputBox, text);
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        // contenteditable div
        inputBox.textContent = text;
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      }
    },

    async submit(inputBox) {
      const submitButton =
        document.querySelector('[data-testid="send-button"]') ||
        document.querySelector('button[aria-label*="Send"]');

      if (submitButton && !submitButton.disabled) {
        submitButton.click();
        return true;
      } else {
        // 备选：按 Enter
        inputBox.dispatchEvent(
          new KeyboardEvent("keydown", {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            bubbles: true,
          })
        );
        return true; // 假设 Enter 键会成功
      }
    },

    getNewChatButton() {
      // ChatGPT的新对话按钮选择器
      return document.querySelector('a[data-testid="create-new-chat-button"]');
    },
  },
};

// Auto-register to global provider list
if (!window.JELLY_PROVIDERS) window.JELLY_PROVIDERS = [];
window.JELLY_PROVIDERS.push(ChatGPTProvider);
