// Gemini Provider
const GeminiProvider = {
  name: "Gemini",
  urlPattern: /https?:\/\/gemini\.google\.com/i,

  adapter: {
    async waitForInputBox(timeout = 10000) {
      const selectors = [
        ".ql-editor",
        'div[contenteditable="true"]',
        "textarea",
      ];

      return waitForElement(selectors, timeout);
    },

    fillText(inputBox, text) {
      if (inputBox.tagName === "TEXTAREA") {
        setNativeValue(inputBox, text);
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        inputBox.textContent = text;
        inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      }
    },

    async submit(inputBox) {
      const submitButton = document.querySelector('button[aria-label*="Send"]');

      if (submitButton && !submitButton.disabled) {
        submitButton.click();
        return true;
      }

      return false; // 未找到提交按钮
    },

    getNewChatButton() {
      // Gemini的新对话按钮选择器
      return (
        document.querySelector('button[aria-label*="New chat"]') ||
        Array.from(document.querySelectorAll("button")).find(
          (btn) =>
            btn.textContent.includes("New chat") ||
            btn.textContent.includes("新对话") ||
            btn.getAttribute("aria-label")?.includes("New chat")
        )
      );
    },
  },
};

// Auto-register to global provider list
if (!window.JELLY_PROVIDERS) window.JELLY_PROVIDERS = [];
window.JELLY_PROVIDERS.push(GeminiProvider);
