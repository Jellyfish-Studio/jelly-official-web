// Jelly Web Helper - Content Script
// Operates on web pages to fill prompts

// 设置标志位，表示 content script 已注入
window.__JELLY_CONTENT_SCRIPT_INJECTED__ = true;

// console.log("[Jelly Web Helper] ✅ Script loaded on:", window.location.href);
// console.log(
//   "[Jelly Web Helper] ✅ Script loaded at:",
//   new Date().toISOString()
// );

// 使用全局注册的 providers（由各个 provider 文件自动注册）
// 添加新 provider 时，只需创建 provider 文件并在 manifest.json 和 popup.html 中引入即可
const PROVIDERS = window.JELLY_PROVIDERS || [];

// 检测当前页面应该使用哪个 provider（在脚本加载时执行一次）
function detectProvider() {
  const currentUrl = window.location.href;
  // console.log("[Jelly Web Helper] Detecting provider for URL:", currentUrl);

  for (const provider of PROVIDERS) {
    if (provider.urlPattern && provider.urlPattern.test(currentUrl)) {
      // console.log("[Jelly Web Helper] Matched provider:", provider.name);
      return provider;
    }
  }

  // console.log("[Jelly Web Helper] No specific provider matched, using Generic");
  return GenericProvider;
}

// 缓存检测到的 provider
const CURRENT_PROVIDER = detectProvider();

console.log(
  "[Jelly Web Helper] ✅ Providers initialized:",
  CURRENT_PROVIDER.name
);

// 向 background 发送握手消息，表示 content script 已就绪
chrome.runtime.sendMessage({
  type: "content_ready",
  data: {
    url: window.location.href,
    provider: CURRENT_PROVIDER.name,
  },
  timestamp: Date.now(),
});

// 监听来自 background 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[Jelly Web Helper] 📨 Received message:", message);
  console.log("[Jelly Web Helper] 📨 Message type:", message.type);

  if (message.type === "fill_prompt") {
    console.log("[Jelly Web Helper] 📨 Processing fill_prompt request");
    fillPrompt(message.data)
      .then(() => {
        console.log("[Jelly Web Helper] ✅ Fill prompt succeeded");
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error("[Jelly Web Helper] ❌ Fill prompt failed:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // 保持消息通道开放
  }

  console.log("[Jelly Web Helper] ⚠️ Unknown message type");
  return false;
});

// 填充提示词
async function fillPrompt(data) {
  // 使用缓存的 provider
  console.log("[Jelly Web Helper] Using provider:", CURRENT_PROVIDER.name);

  try {
    const adapter = CURRENT_PROVIDER.adapter;

    // 从 storage 读取 startNewChat 设置
    const { startNewChat = true } = await chrome.storage.local.get(
      "startNewChat"
    );

    // 如果开启了新对话功能,先点击新对话按钮
    if (startNewChat && adapter.getNewChatButton) {
      const newChatButton = adapter.getNewChatButton();
      if (newChatButton) {
        console.log("[Jelly Web Helper] Clicking new chat button");
        newChatButton.click();
        // 等待一会儿,让新对话界面加载
        await new Promise((resolve) => setTimeout(resolve, 500));
      } else {
        console.log(
          "[Jelly Web Helper] New chat button not found, continuing anyway"
        );
      }
    }

    // 等待输入框加载
    const inputBox = await adapter.waitForInputBox();
    console.log("[Jelly Web Helper] Input box found:", inputBox);

    // 填充文本
    adapter.fillText(inputBox, data.prompt);
    console.log("[Jelly Web Helper] Text filled");

    // 从 storage 读取 autoSubmit 设置
    const { autoSubmit = true } = await chrome.storage.local.get("autoSubmit");

    let submitSuccess = false;

    // 根据设置决定是否自动提交
    if (autoSubmit) {
      await new Promise((resolve) => setTimeout(resolve, 100)); // 短暂延迟确保文本已填充
      submitSuccess = await adapter.submit(inputBox);

      if (submitSuccess) {
        console.log("[Jelly Web Helper] Submitted successfully");
      } else {
        console.log(
          "[Jelly Web Helper] Submit failed - button not found or disabled"
        );
      }
    } else {
      console.log(
        "[Jelly Web Helper] Auto-submit disabled, skipping submission"
      );
    }

    // 发送成功消息到 background
    chrome.runtime.sendMessage({
      type: "fill_result",
      data: {
        success: true,
        // 只在需要提示用户时才发送消息
        message: !autoSubmit
          ? "" // 自动提交关闭，无需提示
          : submitSuccess
          ? "" // 提交成功，无需提示
          : "⚠️ 未找到提交按钮，请手动点击发送", // 提交失败，提示用户
        submitSuccess: submitSuccess,
        autoSubmit: autoSubmit,
        provider: CURRENT_PROVIDER.name,
        url: window.location.href,
      },
      timestamp: Date.now(),
    });
  } catch (error) {
    console.error("[Jelly Web Helper] Error:", error);

    // 发送失败消息到 background
    chrome.runtime.sendMessage({
      type: "fill_result",
      data: {
        success: false,
        message: "❌ " + error.message,
        provider: CURRENT_PROVIDER.name,
        url: window.location.href,
      },
      timestamp: Date.now(),
    });

    throw error;
  }
}
